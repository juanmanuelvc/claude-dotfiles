---
name: pr-drill
description: >-
  Rehearse a pull request locally. Generates an interactive "PR drill" files-changed
  viewer from git diff against main (or another base) so the user can walk the diff
  before pushing. Use when the user asks to review a branch, drill a PR, inspect a
  diff locally, walk files changed, or preview a merge into main without creating a
  remote pull request. For an existing GitHub PR URL, use pr-review-canvas instead.
---

# PR drill

Build a **files changed** viewer from `git diff <base>...<head>`. Do not write
review comments or a verdict unless the user asks. The viewer is for the user
to walk the diff themselves.

## Do this

1. Read this file. Then **run** `scripts/generate.py` — do not reimplement the
   parser, HTML, or canvas UI.
2. From the git repo root:

```bash
python3 ~/.cursor/skills/pr-drill/scripts/generate.py \
  --base main --format auto --name "PR-drill-<topic>"
```

   If the skill lives elsewhere, run `scripts/generate.py` next to this
   `SKILL.md`. Pass `--base origin/main` when `main` is missing. The script
   prints JSON with output paths.

3. **Naming.** `--name` sets the filename stem, and the Cursor canvas tab title
   is derived from it. Always start with `PR-drill-` and preserve acronym
   capitalization in the topic, lowercasing the rest. Example: branch
   `feat/add-oauth-sso` becomes `PR-drill-OAuth-SSO`. Omit `--name` only when
   the branch has no acronyms.

4. **Cursor (canvases dir found, `--format auto` → `canvas`):**
   - The script writes `<name>.canvas.tsx` into the workspace `canvases/`
     directory (`~/.cursor/projects/<workspace-slug>/canvases/`).
   - Reply with a markdown link to that **absolute** `.canvas.tsx` path so it
     opens beside the chat (label like `PR drill`).
   - If `open_resource` is available, also open `file://<absolute-canvas-path>`.
   - Do not mkdir the canvases directory. If the write fails because the dir is
     missing, fall back to `--format html`.

5. **Any other harness (`--format auto` → `html`, or `--format html`):**
   - The script writes a self-contained HTML file (default:
     `<repo>/.git/<name>.html`).
   - Reply with the absolute path. Do not dump the HTML into chat.

6. `--format both` writes canvas (if possible) plus HTML. Use that when the
   user wants a file they can open outside Cursor.

## UX to preserve

The generator already implements this. Do not restyle it:

- Header: `PR drill`, then a muted repo line (`owner/name` from origin, else
  the directory name), then the head branch chip, `into`, the base branch chip,
  the sha range, and `· not pushed` when the branch is ahead of its upstream.
- Stats: `Files`, `Lines vs <base>` (green `+N` / red `−N`), `Reviewed`,
  `Pending`.
- Path search on its own row.
- One filter line: **Change type** left (`All` / `Added` / `Modified` /
  `Deleted` if count > 0, pick one); **Review state** right (`Reviewed` /
  `Pending`, mutually exclusive; click the active chip to clear and show both).
- Default-size pills (not `sm`).
- Reviewed checkboxes and per-file notes persist locally (canvas state or
  `localStorage`). They are never committed.
- Keep the currently open file selected even if filters hide it.

## Defaults

| Flag | Default |
|------|---------|
| `--base` | `main`, else `master`, else `origin/main` |
| `--head` | `HEAD` |
| `--format` | `auto` |
| `--name` | `PR-drill-<branch>` |

Do not add generated HTML or canvas files to git.

## Portable HTML

`scripts/viewer.html` is a single file, no build, no npm. Open it in any
browser. Cursor canvas (`scripts/canvas.tsx.tpl`) is Cursor-only
(`cursor/canvas`). Keep both generated from the same parsed diff in
`generate.py`.
