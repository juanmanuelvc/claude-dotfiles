#!/usr/bin/env python3
"""Generate a local files-changed review from git diff.

Emits a self-contained HTML viewer (any browser) and/or a Cursor .canvas.tsx.
"""

from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import sys
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
VIEWER_HTML = SCRIPT_DIR / "viewer.html"
CANVAS_TPL = SCRIPT_DIR / "canvas.tsx.tpl"
HUNK_RE = re.compile(r"^@@ -(\d+)(?:,\d+)? \+(\d+)(?:,\d+)? @@")


def run(args: list[str], cwd: Path) -> str:
    return subprocess.check_output(args, cwd=cwd, text=True).rstrip("\n")


def git_ok(args: list[str], cwd: Path) -> str | None:
    try:
        return subprocess.check_output(args, cwd=cwd, text=True, stderr=subprocess.DEVNULL).rstrip("\n")
    except subprocess.CalledProcessError:
        return None


def resolve_base(repo: Path, base: str | None) -> str:
    if base:
        return base
    for candidate in ("main", "master", "origin/main", "origin/master"):
        if git_ok(["git", "rev-parse", "--verify", candidate], repo) is not None:
            return candidate
    return "HEAD"


def parse_diff(raw: str) -> list[dict]:
    files: list[dict] = []
    current: dict | None = None
    old_ln = new_ln = 0

    def flush() -> None:
        nonlocal current
        if current and current.get("path") and current["path"] != "/dev/null":
            adds = sum(1 for line in current["lines"] if line["type"] == "added")
            dels = sum(1 for line in current["lines"] if line["type"] == "removed")
            current["additions"] = adds
            current["deletions"] = dels
            files.append(current)
        current = None

    for line in raw.splitlines():
        if line.startswith("diff --git "):
            flush()
            current = {"path": "", "status": "modified", "lines": []}
            continue
        if current is None:
            continue
        if line.startswith("+++ b/") and not line.startswith("+++ b/dev/null"):
            current["path"] = line[6:]
            continue
        if line.startswith("--- a/") and line != "--- a/dev/null":
            if not current["path"]:
                current["path"] = line[6:]
            continue
        if line.startswith("new file mode"):
            current["status"] = "added"
            continue
        if line.startswith("deleted file mode"):
            current["status"] = "deleted"
            continue
        if line.startswith("@@"):
            match = HUNK_RE.match(line)
            if match:
                old_ln = int(match.group(1))
                new_ln = int(match.group(2))
                current["lines"].append(
                    {"type": "unchanged", "content": line, "lineNumber": new_ln}
                )
            continue
        if line.startswith(("index ", "--- ", "+++ ", "similarity ", "rename ", "\\")):
            continue
        if line.startswith("+"):
            current["lines"].append(
                {"type": "added", "content": line[1:], "lineNumber": new_ln}
            )
            new_ln += 1
        elif line.startswith("-"):
            current["lines"].append(
                {"type": "removed", "content": line[1:], "lineNumber": old_ln}
            )
            old_ln += 1
        else:
            content = line[1:] if line.startswith(" ") else line
            current["lines"].append(
                {"type": "unchanged", "content": content, "lineNumber": new_ln}
            )
            old_ln += 1
            new_ln += 1
    flush()
    return files


def repo_label(repo: Path) -> str:
    url = git_ok(["git", "remote", "get-url", "origin"], repo)
    if url:
        cleaned = url.strip().rstrip("/")
        if cleaned.endswith(".git"):
            cleaned = cleaned[:-4]
        if "://" in cleaned:
            path = cleaned.split("://", 1)[1]
            parts = [part for part in path.split("/") if part]
            if len(parts) >= 2:
                return f"{parts[-2]}/{parts[-1]}"
        elif ":" in cleaned:
            path = cleaned.split(":", 1)[1]
            parts = [part for part in path.split("/") if part]
            if len(parts) >= 2:
                return f"{parts[-2]}/{parts[-1]}"
    return repo.name


def slug(value: str) -> str:
    cleaned = re.sub(r"[^a-zA-Z0-9]+", "-", value).strip("-").lower()
    return cleaned or "head"


def cursor_canvases_dir(repo: Path) -> Path | None:
    explicit = os.environ.get("CURSOR_CANVASES_DIR")
    if explicit:
        return Path(explicit)
    projects = Path.home() / ".cursor" / "projects"
    if not projects.is_dir():
        return None
    resolved = repo.resolve()
    slug_name = str(resolved).lstrip("/").replace("/", "-")
    direct = projects / slug_name / "canvases"
    if direct.parent.is_dir():
        return direct
    name = resolved.name
    matches = [path / "canvases" for path in projects.iterdir() if path.name.endswith(name)]
    if len(matches) == 1:
        return matches[0]
    return None


def collect_payload(repo: Path, base_ref: str, head_ref: str) -> dict:
    branch = git_ok(["git", "rev-parse", "--abbrev-ref", head_ref], repo) or head_ref
    head_sha = run(["git", "rev-parse", "--short", head_ref], repo)
    base_sha = run(["git", "rev-parse", "--short", base_ref], repo)
    merge_base = git_ok(["git", "merge-base", base_ref, head_ref], repo)
    range_spec = f"{merge_base}...{head_ref}" if merge_base else f"{base_ref}...{head_ref}"
    raw = run(["git", "diff", "-U3", range_spec], repo)
    files = parse_diff(raw)
    additions = sum(item["additions"] for item in files)
    deletions = sum(item["deletions"] for item in files)
    upstream = git_ok(["git", "rev-parse", "--abbrev-ref", "--symbolic-full-name", "@{u}"], repo)
    unpushed = True
    if upstream:
        counts = git_ok(["git", "rev-list", "--left-right", "--count", f"{upstream}...{head_ref}"], repo)
        if counts:
            ahead = int(counts.split()[1])
            unpushed = ahead > 0
    store_key = f"pr-drill:{repo.resolve()}:{base_sha}:{head_sha}"
    return {
        "repo": repo_label(repo),
        "branch": branch,
        "base": base_ref,
        "baseSha": base_sha,
        "headSha": head_sha,
        "unpushed": unpushed,
        "storeKey": store_key,
        "additions": additions,
        "deletions": deletions,
        "files": [
            {
                "path": item["path"],
                "status": item["status"],
                "additions": item["additions"],
                "deletions": item["deletions"],
            }
            for item in files
        ],
        "diffs": {item["path"]: item["lines"] for item in files},
    }


def write_html(payload: dict, dest: Path) -> None:
    template = VIEWER_HTML.read_text()
    encoded = json.dumps(payload).replace("<", "\\u003c")
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(template.replace("__PAYLOAD__", encoded))


def write_canvas(payload: dict, dest: Path) -> None:
    source = CANVAS_TPL.read_text()
    replacements = {
        "__REPO__": json.dumps(payload["repo"]),
        "__BRANCH__": json.dumps(payload["branch"]),
        "__BASE__": json.dumps(payload["base"]),
        "__BASE_SHA__": json.dumps(payload["baseSha"]),
        "__HEAD_SHA__": json.dumps(payload["headSha"]),
        "__UNPUSHED__": json.dumps(payload["unpushed"]),
        "__FILES__": json.dumps(payload["files"], indent=2),
        "__DIFFS__": json.dumps(payload["diffs"]),
    }
    for token, value in replacements.items():
        source = source.replace(token, value)
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(source)


def default_stem(payload: dict) -> str:
    branch = payload["branch"].split("/")[-1]
    return f"PR-drill-{slug(branch)}"


def choose_formats(fmt: str, canvases: Path | None) -> list[str]:
    if fmt == "auto":
        return ["canvas"] if canvases is not None else ["html"]
    if fmt == "both":
        return ["canvas", "html"]
    return [fmt]


def main() -> int:
    parser = argparse.ArgumentParser(description="Generate a local PR files-changed review.")
    parser.add_argument("--repo", default=".", help="Git repository root (default: cwd)")
    parser.add_argument("--base", default=None, help="Base ref (default: main/master)")
    parser.add_argument("--head", default="HEAD", help="Head ref (default: HEAD)")
    parser.add_argument(
        "--format",
        choices=("auto", "canvas", "html", "both"),
        default="auto",
        help="auto: Cursor canvas when a canvases dir is found, else HTML",
    )
    parser.add_argument("--out", default=None, help="Output path (single format only)")
    parser.add_argument(
        "--name",
        default=None,
        help="Output filename stem, e.g. PR-drill-OAuth-SSO (casing is preserved)",
    )
    args = parser.parse_args()

    repo = Path(args.repo).resolve()
    if not (repo / ".git").exists() and git_ok(["git", "rev-parse", "--show-toplevel"], repo) is None:
        print("error: not a git repository", file=sys.stderr)
        return 1
    toplevel = git_ok(["git", "rev-parse", "--show-toplevel"], repo)
    if toplevel:
        repo = Path(toplevel)

    base_ref = resolve_base(repo, args.base)
    payload = collect_payload(repo, base_ref, args.head)
    canvases = cursor_canvases_dir(repo)
    formats = choose_formats(args.format, canvases)
    if args.out and len(formats) > 1:
        print("error: --out requires a single --format (canvas or html)", file=sys.stderr)
        return 1

    stem = args.name or default_stem(payload)
    written: dict[str, str] = {}
    for kind in formats:
        if kind == "canvas":
            dest = Path(args.out) if args.out else (canvases or repo) / f"{stem}.canvas.tsx"
            write_canvas(payload, dest)
            written["canvas"] = str(dest)
        else:
            dest = Path(args.out) if args.out else repo / ".git" / f"{stem}.html"
            write_html(payload, dest)
            written["html"] = str(dest)

    result = {
        "ok": True,
        "branch": payload["branch"],
        "base": payload["base"],
        "files": len(payload["files"]),
        "additions": payload["additions"],
        "deletions": payload["deletions"],
        "canvasesDir": str(canvases) if canvases else None,
        **written,
    }
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
