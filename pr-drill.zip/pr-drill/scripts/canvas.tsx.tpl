import {
  Button,
  Card,
  categoryPaletteDark,
  categoryPaletteLight,
  CardBody,
  CardHeader,
  Checkbox,
  DiffStats,
  DiffView,
  Divider,
  H1,
  Pill,
  Row,
  Spacer,
  Stack,
  Stat,
  Text,
  TextArea,
  TextInput,
  useCanvasAction,
  useCanvasState,
  useHostTheme,
} from "cursor/canvas";

type DiffLineType = "added" | "removed" | "unchanged";
type DiffLine = { type: DiffLineType; content: string; lineNumber?: number };
type ChangedFile = {
  path: string;
  status: "added" | "modified" | "deleted";
  additions: number;
  deletions: number;
};
type StatusFilter = "all" | ChangedFile["status"];
type ReviewFilter = "none" | "reviewed" | "pending";

const REPO = __REPO__;
const BRANCH = __BRANCH__;
const BASE = __BASE__;
const BASE_SHA = __BASE_SHA__;
const HEAD_SHA = __HEAD_SHA__;
const UNPUSHED = __UNPUSHED__;

const FILES: ChangedFile[] = __FILES__;

const DIFFS: Record<string, DiffLine[]> = __DIFFS__;

const STATUS_ORDER: StatusFilter[] = ["all", "added", "modified", "deleted"];
const STATUS_LABEL: Record<StatusFilter, string> = {
  all: "All",
  added: "Added",
  modified: "Modified",
  deleted: "Deleted",
};

function fileName(path: string): string {
  const parts = path.split("/");
  return parts[parts.length - 1] ?? path;
}

const TOTAL_ADDITIONS = FILES.reduce((sum, file) => sum + file.additions, 0);
const TOTAL_DELETIONS = FILES.reduce((sum, file) => sum + file.deletions, 0);

function DiffTotals() {
  const theme = useHostTheme();
  const palette = theme.kind === "light" ? categoryPaletteLight : categoryPaletteDark;
  return (
    <span>
      <span style={{ color: palette.green }}>+{TOTAL_ADDITIONS}</span>
      <span style={{ color: theme.text.quaternary }}> / </span>
      <span style={{ color: palette.red }}>&minus;{TOTAL_DELETIONS}</span>
    </span>
  );
}

function statusCount(status: StatusFilter): number {
  return status === "all"
    ? FILES.length
    : FILES.filter((file) => file.status === status).length;
}

function BranchChip({ name }: { name: string }) {
  const theme = useHostTheme();
  return (
    <span
      style={{
        background: theme.fill.tertiary,
        border: `1px solid ${theme.stroke.tertiary}`,
        borderRadius: 6,
        color: theme.accent.primary,
        fontFamily: "ui-monospace, SFMono-Regular, Menlo, monospace",
        fontSize: 12,
        lineHeight: "18px",
        padding: "1px 6px",
        whiteSpace: "nowrap",
      }}
    >
      {name}
    </span>
  );
}

function GroupLabel({ text }: { text: string }) {
  return (
    <Text size="small" tone="tertiary">
      {text}
    </Text>
  );
}

export default function PrFilesReview() {
  const dispatch = useCanvasAction();
  const firstPath = FILES[0] ? FILES[0].path : "";
  const [query, setQuery] = useCanvasState("pr-files-query", "");
  const [selected, setSelected] = useCanvasState("pr-files-selected", firstPath);
  const [reviewed, setReviewed] = useCanvasState<Record<string, boolean>>("pr-files-reviewed", {});
  const [notes, setNotes] = useCanvasState<Record<string, string>>("pr-files-notes", {});
  const [reviewFilter, setReviewFilter] = useCanvasState<ReviewFilter>("pr-files-review-filter", "none");
  const [statusFilter, setStatusFilter] = useCanvasState<StatusFilter>("pr-files-status", "all");

  const q = query.trim().toLowerCase();
  const visible = FILES.filter((file) => {
    if (statusFilter !== "all" && file.status !== statusFilter) return false;
    if (reviewFilter === "reviewed" && !reviewed[file.path]) return false;
    if (reviewFilter === "pending" && reviewed[file.path]) return false;
    if (q && !file.path.toLowerCase().includes(q)) return false;
    return true;
  });

  const current = FILES.find((file) => file.path === selected) ?? FILES[0];
  const lines = current ? DIFFS[current.path] ?? [] : [];
  const reviewedCount = FILES.filter((file) => reviewed[file.path]).length;
  const remaining = FILES.length - reviewedCount;
  const statusOptions = STATUS_ORDER.filter(
    (status) => status === "all" || statusCount(status) > 0,
  );

  return (
    <Stack gap={16}>
      <Stack gap={8}>
        <H1>PR drill</H1>
        <Text size="small" tone="secondary">
          {REPO}
        </Text>
        <Row gap={6} align="center" wrap>
          <BranchChip name={BRANCH} />
          <Text size="small" tone="tertiary">
            into
          </Text>
          <BranchChip name={BASE} />
          <Text size="small" tone="tertiary">
            {BASE_SHA}...{HEAD_SHA}
            {UNPUSHED ? " · not pushed" : ""}
          </Text>
        </Row>
        <Text tone="secondary" size="small">
          Files changed · local review, nothing is posted
        </Text>
      </Stack>

      <Row gap={20} wrap>
        <Stat value={String(FILES.length)} label="Files" />
        <Stat value={<DiffTotals />} label={`Lines vs ${BASE}`} />
        <Stat value={String(reviewedCount)} label="Reviewed" />
        <Stat value={String(remaining)} label="Pending" />
      </Row>

      <TextInput
        value={query}
        onChange={setQuery}
        placeholder="Filter by path…"
        style={{ maxWidth: 320 }}
      />

      <Row gap={16} align="center" justify="space-between">
        <GroupLabel text="Change type" />
        <GroupLabel text="Review state" />
      </Row>

      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          gap: 16,
          overflowX: "auto",
        }}
      >
        <div style={{ display: "flex", gap: 6, flexShrink: 0 }}>
          {statusOptions.map((status) => (
            <div key={status}>
              <Pill
                active={statusFilter === status}
                title={`Show only ${STATUS_LABEL[status].toLowerCase()} files`}
                onClick={() => setStatusFilter(status)}
              >
                {STATUS_LABEL[status]} {statusCount(status)}
              </Pill>
            </div>
          ))}
        </div>

        <div style={{ display: "flex", gap: 6, flexShrink: 0 }}>
          <Pill
            active={reviewFilter === "reviewed"}
            title="Toggle off to show reviewed and pending together"
            onClick={() =>
              setReviewFilter(reviewFilter === "reviewed" ? "none" : "reviewed")
            }
          >
            Reviewed {reviewedCount}
          </Pill>
          <Pill
            active={reviewFilter === "pending"}
            title="Toggle off to show reviewed and pending together"
            onClick={() =>
              setReviewFilter(reviewFilter === "pending" ? "none" : "pending")
            }
          >
            Pending {remaining}
          </Pill>
        </div>
      </div>

      <Divider />

      {current ? (
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "minmax(220px, 280px) minmax(0, 1fr)",
          gap: 16,
          alignItems: "start",
        }}
      >
        <Stack gap={4}>
          <Text size="small" tone="tertiary">
            {visible.length === FILES.length
              ? `${FILES.length} files`
              : `${visible.length} of ${FILES.length} files`}
          </Text>
          {visible.length === 0 ? (
            <Row gap={8} align="center">
              <Text size="small" tone="secondary">
                No files match.
              </Text>
              <Button
                variant="ghost"
                onClick={() => {
                  setStatusFilter("all");
                  setReviewFilter("none");
                  setQuery("");
                }}
              >
                Clear filters
              </Button>
            </Row>
          ) : null}
          {visible.map((file) => (
            <div key={file.path}>
              <Row gap={6} align="center">
                <Checkbox
                  checked={Boolean(reviewed[file.path])}
                  onChange={(checked) =>
                    setReviewed({ ...reviewed, [file.path]: checked })
                  }
                />
                <Button
                  variant={file.path === current.path ? "secondary" : "ghost"}
                  onClick={() => setSelected(file.path)}
                >
                  {fileName(file.path)}
                </Button>
                <Spacer />
                <DiffStats additions={file.additions} deletions={file.deletions} />
              </Row>
            </div>
          ))}
        </Stack>

        <Stack gap={10}>
          <Card>
            <CardHeader
              trailing={
                <DiffStats additions={current.additions} deletions={current.deletions} />
              }
            >
              {current.path}
            </CardHeader>
            <CardBody style={{ padding: 0 }}>
              <DiffView path={current.path} lines={lines} />
            </CardBody>
          </Card>
          <Row gap={8} align="center" wrap>
            <Button
              variant="primary"
              onClick={() => dispatch({ type: "openFile", path: current.path })}
            >
              Open file
            </Button>
            <Checkbox
              checked={Boolean(reviewed[current.path])}
              onChange={(checked) =>
                setReviewed({ ...reviewed, [current.path]: checked })
              }
              label="Reviewed"
            />
            <Text size="small" tone="tertiary">
              {current.status}
            </Text>
          </Row>
          <Text size="small" tone="secondary">
            Notes stay on this canvas. They are not committed or posted.
          </Text>
          <TextArea
            rows={3}
            value={notes[current.path] ?? ""}
            onChange={(value) => setNotes({ ...notes, [current.path]: value })}
            placeholder="Your notes on this file…"
          />
        </Stack>
      </div>
      ) : (
        <Text tone="secondary">No diff against {BASE}.</Text>
      )}
    </Stack>
  );
}
