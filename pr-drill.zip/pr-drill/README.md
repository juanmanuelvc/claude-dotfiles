# PR drill

Local files-changed viewer for walking a branch diff before you push. No remote
pull request required.

## Install

Copy this directory to `~/.cursor/skills/pr-drill`. Cursor will pick it up as a
personal skill on the next chat.

## Use

Ask the agent to run a PR drill against `main`, or invoke `pr-drill`. The
generator lives at `scripts/generate.py` and can also be run directly:

```bash
python3 ~/.cursor/skills/pr-drill/scripts/generate.py --base main --format auto --name "PR-drill-<topic>"
```

`--format auto` writes a Cursor canvas when a `canvases/` directory exists,
otherwise a self-contained HTML file under `<repo>/.git/`.

Do not commit generated `.canvas.tsx` or HTML files.
